﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ElevatorProject
{
    public enum Floor
    {
        Ground = 1,
        Secret = 2,
        T1 = 3,
        T2 = 4
    }
}
